export const REMOTE_SKETCHBOOK_FOLDER = 'RemoteSketchbook';
export const ARDUINO_CLOUD_FOLDER = 'ArduinoCloud';
